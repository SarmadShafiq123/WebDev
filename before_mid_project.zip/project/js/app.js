import { setupPersonalInfo } from './modules/personal.js';
import { setupSections } from './modules/sections.js';
import { setupSkills } from './modules/skills.js';
import { setupPdfExport } from './modules/pdf.js';
import { setupDragAndDrop } from './modules/dragdrop.js';

document.addEventListener('DOMContentLoaded', () => {
    setupPersonalInfo();
    setupSections();
    setupSkills();
    setupPdfExport();
    setupDragAndDrop();
});