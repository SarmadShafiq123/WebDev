import { state, updateState } from './state.js';
import { updatePreview } from './preview.js';

export function setupPersonalInfo() {
    const fields = ['fullName', 'email', 'phone', 'summary'];
    fields.forEach(field => {
        document.getElementById(field).addEventListener('input', handlePersonalInfoChange);
    });
}

function handlePersonalInfoChange(e) {
    const field = e.target.id;
    const value = e.target.value;
    const mappings = {
        fullName: 'name',
        email: 'email',
        phone: 'phone',
        summary: 'summary'
    };

    updateState('personal', { [mappings[field]]: value });
    updatePreview();
}