import { state } from './state.js';

export function updatePreview() {
    updatePersonalInfo();
    updateExperience();
    updateEducation();
    updateSkills();
}

function updatePersonalInfo() {
    document.getElementById('previewName').textContent = state.personal.name || 'Your Name';
    document.getElementById('previewEmail').textContent = state.personal.email;
    document.getElementById('previewPhone').textContent = state.personal.phone;
    document.getElementById('previewSummary').textContent = state.personal.summary;
}

function updateExperience() {
    const html = state.experience.map(exp => `
        <div class="preview-item">
            <h3>${exp.title}</h3>
            <p>${exp.company} | ${exp.period}</p>
            <p>${exp.description}</p>
        </div>
    `).join('');
    document.getElementById('previewExperience').innerHTML = html;
}

function updateEducation() {
    const html = state.education.map(edu => `
        <div class="preview-item">
            <h3>${edu.degree}</h3>
            <p>${edu.school} | ${edu.year}</p>
            <p>${edu.description}</p>
        </div>
    `).join('');
    document.getElementById('previewEducation').innerHTML = html;
}

function updateSkills() {
    const html = state.skills.map(skill => 
        `<span class="skill-tag">${skill}</span>`
    ).join('');
    document.getElementById('previewSkills').innerHTML = html;
}