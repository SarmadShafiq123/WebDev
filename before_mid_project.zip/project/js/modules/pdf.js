export function setupPdfExport() {
    document.getElementById('downloadBtn').addEventListener('click', generatePDF);
}

function generatePDF() {
    const element = document.getElementById('resumePreview');
    const opt = {
        margin: 1,
        filename: 'resume.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
    };

    html2pdf().set(opt).from(element).save();
}