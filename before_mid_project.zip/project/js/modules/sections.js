import { state, updateState } from './state.js';
import { updatePreview } from './preview.js';

export function setupSections() {
    document.querySelectorAll('.add-btn[data-section]').forEach(button => {
        button.addEventListener('click', () => addSection(button.dataset.section));
    });
}

function addSection(type) {
    const list = document.getElementById(`${type}List`);
    const item = createSectionItem(type);
    list.appendChild(item);
    
    const newItem = type === 'experience' 
        ? { title: '', company: '', period: '', description: '' }
        : { degree: '', school: '', year: '', description: '' };
    
    state[type].push(newItem);
    updatePreview();
}

function createSectionItem(type) {
    const div = document.createElement('div');
    div.className = 'sortable-item';
    div.draggable = true;
    
    const fields = type === 'experience' 
        ? ['title', 'company', 'period', 'description']
        : ['degree', 'school', 'year', 'description'];
    
    div.innerHTML = `
        <button class="delete-btn" onclick="removeSection(this, '${type}')">&times;</button>
        ${fields.map(field => `
            <div class="form-group">
                <input type="text" 
                       class="form-input" 
                       placeholder="${field.charAt(0).toUpperCase() + field.slice(1)}"
                       onchange="updateSection(this, '${type}', '${field}')">
            </div>
        `).join('')}
    `;
    
    return div;
}

export function removeSection(button, type) {
    const item = button.parentElement;
    const list = item.parentElement;
    const index = Array.from(list.children).indexOf(item);
    
    state[type].splice(index, 1);
    item.remove();
    updatePreview();
}

export function updateSection(input, type, field) {
    const item = input.closest('.sortable-item');
    const list = item.parentElement;
    const index = Array.from(list.children).indexOf(item);
    
    state[type][index][field] = input.value;
    updatePreview();
}