export const state = {
    personal: {
        name: '',
        email: '',
        phone: '',
        summary: ''
    },
    experience: [],
    education: [],
    skills: []
};

export function updateState(section, data) {
    if (section === 'personal') {
        state.personal = { ...state.personal, ...data };
    } else {
        state[section] = data;
    }
}