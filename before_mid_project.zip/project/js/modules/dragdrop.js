import { updatePreview } from './preview.js';

export function setupDragAndDrop() {
    const lists = document.querySelectorAll('.sortable-list');
    lists.forEach(setupDraggableList);
}

function setupDraggableList(list) {
    let draggedItem = null;

    list.addEventListener('dragstart', e => {
        draggedItem = e.target;
        e.target.classList.add('dragging');
    });

    list.addEventListener('dragend', e => {
        e.target.classList.remove('dragging');
        updatePreview();
    });

    list.addEventListener('dragover', e => {
        e.preventDefault();
        const afterElement = getDragAfterElement(list, e.clientY);
        const item = document.querySelector('.dragging');
        
        if (afterElement) {
            list.insertBefore(item, afterElement);
        } else {
            list.appendChild(item);
        }
    });
}

function getDragAfterElement(container, y) {
    const draggableElements = [...container.querySelectorAll('.sortable-item:not(.dragging)')];

    return draggableElements.reduce((closest, child) => {
        const box = child.getBoundingClientRect();
        const offset = y - box.top - box.height / 2;
        
        if (offset < 0 && offset > closest.offset) {
            return { offset, element: child };
        }
        return closest;
    }, { offset: Number.NEGATIVE_INFINITY }).element;
}