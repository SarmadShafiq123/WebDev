import { state, updateState } from './state.js';
import { updatePreview } from './preview.js';

export function setupSkills() {
    const addButton = document.getElementById('addSkillBtn');
    const input = document.getElementById('skillInput');
    
    addButton.addEventListener('click', () => addSkill(input));
    input.addEventListener('keypress', e => {
        if (e.key === 'Enter') addSkill(input);
    });
}

function addSkill(input) {
    const skill = input.value.trim();
    
    if (skill && !state.skills.includes(skill)) {
        state.skills.push(skill);
        updateSkillsList();
        updatePreview();
        input.value = '';
    }
}

function removeSkill(skill) {
    state.skills = state.skills.filter(s => s !== skill);
    updateSkillsList();
    updatePreview();
}

function updateSkillsList() {
    const skillsList = document.getElementById('skillsList');
    skillsList.innerHTML = '';
    
    state.skills.forEach(skill => {
        const skillTag = document.createElement('div');
        skillTag.className = 'skill-tag';
        skillTag.innerHTML = `
            ${skill}
            <button onclick="removeSkill('${skill}')">&times;</button>
        `;
        skillsList.appendChild(skillTag);
    });
}