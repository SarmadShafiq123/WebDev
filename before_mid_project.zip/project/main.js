// State management
let state = {
    personal: {
        name: '',
        email: '',
        phone: '',
        summary: ''
    },
    experience: [],
    education: [],
    skills: []
};

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    setupPersonalInfoListeners();
    setupDragAndDrop();
});

// Personal Information Handlers
function setupPersonalInfoListeners() {
    const personalFields = ['fullName', 'email', 'phone', 'summary'];
    personalFields.forEach(field => {
        document.getElementById(field).addEventListener('input', (e) => {
            updatePersonalInfo(field, e.target.value);
        });
    });
}

function updatePersonalInfo(field, value) {
    const mappings = {
        fullName: 'name',
        email: 'email',
        phone: 'phone',
        summary: 'summary'
    };

    state.personal[mappings[field]] = value;
    updatePreview();
}

// Experience Section
function addExperience() {
    const experienceList = document.getElementById('experienceList');
    const experienceItem = createSectionItem('experience');
    experienceList.appendChild(experienceItem);
    
    state.experience.push({
        title: '',
        company: '',
        period: '',
        description: ''
    });
    
    updatePreview();
}

// Education Section
function addEducation() {
    const educationList = document.getElementById('educationList');
    const educationItem = createSectionItem('education');
    educationList.appendChild(educationItem);
    
    state.education.push({
        degree: '',
        school: '',
        year: '',
        description: ''
    });
    
    updatePreview();
}

// Skills Section
function addSkill() {
    const skillInput = document.getElementById('skillInput');
    const skill = skillInput.value.trim();
    
    if (skill && !state.skills.includes(skill)) {
        state.skills.push(skill);
        updateSkillsList();
        updatePreview();
        skillInput.value = '';
    }
}

function removeSkill(skill) {
    state.skills = state.skills.filter(s => s !== skill);
    updateSkillsList();
    updatePreview();
}

function updateSkillsList() {
    const skillsList = document.getElementById('skillsList');
    skillsList.innerHTML = '';
    
    state.skills.forEach(skill => {
        const skillTag = document.createElement('div');
        skillTag.className = 'skill-tag';
        skillTag.innerHTML = `
            ${skill}
            <button onclick="removeSkill('${skill}')">&times;</button>
        `;
        skillsList.appendChild(skillTag);
    });
}

// Drag and Drop
function setupDragAndDrop() {
    const lists = document.querySelectorAll('.sortable-list');
    lists.forEach(list => {
        new Sortable(list, {
            animation: 150,
            onEnd: () => updatePreview()
        });
    });
}

// Helper Functions
function createSectionItem(type) {
    const div = document.createElement('div');
    div.className = 'sortable-item';
    div.draggable = true;
    
    const fields = type === 'experience' 
        ? ['title', 'company', 'period', 'description']
        : ['degree', 'school', 'year', 'description'];
    
    div.innerHTML = `
        <button class="delete-btn" onclick="removeSection(this, '${type}')">&times;</button>
        ${fields.map(field => `
            <div class="form-group">
                <input type="text" 
                       class="form-input" 
                       placeholder="${field.charAt(0).toUpperCase() + field.slice(1)}"
                       onchange="updateSection(this, '${type}', '${field}')">
            </div>
        `).join('')}
    `;
    
    return div;
}

function removeSection(button, type) {
    const item = button.parentElement;
    const list = item.parentElement;
    const index = Array.from(list.children).indexOf(item);
    
    state[type].splice(index, 1);
    item.remove();
    updatePreview();
}

function updateSection(input, type, field) {
    const item = input.closest('.sortable-item');
    const list = item.parentElement;
    const index = Array.from(list.children).indexOf(item);
    
    state[type][index][field] = input.value;
    updatePreview();
}

// Preview Updates
function updatePreview() {
    // Update personal information
    document.getElementById('previewName').textContent = state.personal.name || 'Your Name';
    document.getElementById('previewEmail').textContent = state.personal.email;
    document.getElementById('previewPhone').textContent = state.personal.phone;
    document.getElementById('previewSummary').textContent = state.personal.summary;

    // Update experience
    const experienceHTML = state.experience.map(exp => `
        <div class="preview-item">
            <h3>${exp.title}</h3>
            <p>${exp.company} | ${exp.period}</p>
            <p>${exp.description}</p>
        </div>
    `).join('');
    document.getElementById('previewExperience').innerHTML = experienceHTML;

    // Update education
    const educationHTML = state.education.map(edu => `
        <div class="preview-item">
            <h3>${edu.degree}</h3>
            <p>${edu.school} | ${edu.year}</p>
            <p>${edu.description}</p>
        </div>
    `).join('');
    document.getElementById('previewEducation').innerHTML = educationHTML;

    // Update skills
    const skillsHTML = state.skills.map(skill => 
        `<span class="skill-tag">${skill}</span>`
    ).join('');
    document.getElementById('previewSkills').innerHTML = skillsHTML;
}

// PDF Generation
function generatePDF() {
    const element = document.getElementById('resumePreview');
    const opt = {
        margin: 1,
        filename: 'resume.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
    };

    html2pdf().set(opt).from(element).save();
}